import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import NoteTaker from './NoteTaker';
import NotesContainer from './NotesContainer';
import { withStyles } from '@material-ui/core';

const styles = theme => ({
    container:{
        margin: 20,        
    },
});



class NotesApp extends Component {
    render() {
        const { classes, notes, handleAddNote, handleRemoveNote } = this.props;
        return (
            <Grid container spacing={8} className={classes.container}>
                <Grid item xs={12}>
                    <NoteTaker handleAddNote={handleAddNote} />
                </Grid>
                <Grid item xs={12}>
                    <NotesContainer notes={notes} handleRemoveNote={handleRemoveNote} />
                </Grid>
            </Grid>
        );
    }
}

export default withStyles(styles)(NotesApp);