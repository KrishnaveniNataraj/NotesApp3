import React, { Fragment } from 'react';
import { MDBCarousel, MDBCarouselInner, MDBCarouselItem, MDBView, MDBMask, MDBContainer, MDBJumbotron } from "mdbreact";

import notes_studying from '../images/pen-writing-notes-studying.jpg';
import note2Img from '../images/notes-2.jpg';
import note3Img from '../images/notes-3.jpg';


function WelcomePage(props) {
    return (
        <Fragment>
            <MDBContainer>
                <MDBCarousel activeItem={1} length={3} showControls={true} showIndicators={true} className="z-depth-1">
                    <MDBCarouselInner>
                        <MDBCarouselItem itemId="1">
                            <MDBView>
                                <img className="d-block w-100" src={notes_studying} alt="First slide" />                                
                                <MDBMask overlay="black-light" />
                            </MDBView>
                        </MDBCarouselItem>
                        <MDBCarouselItem itemId="2">
                            <MDBView>
                                <img className="d-block w-100" src={note2Img} alt="Second slide" />
                                <MDBMask overlay="black-strong" />
                            </MDBView>
                        </MDBCarouselItem>
                        <MDBCarouselItem itemId="3">
                            <MDBView>
                                <img className="d-block w-100" src={note3Img} alt="Third slide" />
                                <MDBMask overlay="black-slight" />
                            </MDBView>
                        </MDBCarouselItem>                       
                    </MDBCarouselInner>
                </MDBCarousel>
            </MDBContainer>

            <MDBJumbotron>
                <MDBContainer>
                    <h2 className="display-4">Focus on what matters most</h2>
                    <p className="lead">Plan, keep records, and manage projects from any device–even offline.</p>
                </MDBContainer>
            </MDBJumbotron>
           
        </Fragment>
    );


};

export default WelcomePage;