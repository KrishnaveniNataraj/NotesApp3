import * as firebase from 'firebase';


 // Initialize Firebase
 const config = {
    apiKey: "AIzaSyCWIWDpKUFkQgSpD3JEeyb5El8nKWry7mk",
    authDomain: "notes-app-7d00b.firebaseapp.com",
    databaseURL: "https://notes-app-7d00b.firebaseio.com",
    projectId: "notes-app-7d00b",
    storageBucket: "notes-app-7d00b.appspot.com",
    messagingSenderId: "283469837274"
  };
  firebase.initializeApp(config);

  const googleAuthProvider =new firebase.auth.GoogleAuthProvider();

  export {firebase, googleAuthProvider};